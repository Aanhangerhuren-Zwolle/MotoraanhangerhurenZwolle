# MotorTrailer Zwolle — live te zetten

Dit pakket is de **afgewerkte productie-build**. Alle techniek is ingeplugd en gecontroleerd. Klaar om te deployen.

```
index.html
assets/
  ├─ hero-trailer2.jpg   (hero + foto Trailer 2, gecomprimeerd)
  └─ trailer1.jpg        (foto Trailer 1)
```

## Deployen (GitHub Pages)
Upload `index.html` naar de **root** van je repo en de map `assets/` ernaast (dus `assets/hero-trailer2.jpg` en `assets/trailer1.jpg`). GitHub Pages serveert `index.html` automatisch. Klaar.

> Let op: vervang de oude losse afbeelding `motor-op-trailer-Zwolle.jpg` niet — die wordt niet meer gebruikt. De nieuwe site verwijst naar `assets/`.

## Wat er is ingeplugd en gecontroleerd
- **GA4** (G-EBXEG9LKBH) — actief in `<head>`.
- **Per-knop tracking** — losse events zodat je in GA4 per knop ziet wat er gebeurt:
  `whatsapp_click`, `bel_click`, `facebook_review_click`, `cta_reserveren`,
  `trailer_select`, `reservation_form_submit` (elk met `locatie`/`trailer`-label).
- **Microsoft Clarity** (xanuxjn7xo) — heatmaps + sessie-opnames.
- **Google Calendar** — bestaande agenda-embed als iframe (#reserveren).
- **WhatsApp** — alle 5 knoppen naar 06-83 31 82 86 (`wa.me/31683318286`) met het
  standaardbericht "Hoi! Ik wil een motortrailer huren in Zwolle." Het formulier
  bouwt het volledige bericht op uit de velden (naam verplicht).
- **Facebook-aanbeveling** — reviewknop linkt naar je Facebook-pagina.
- **SEO** — meta description, keywords, og-tags, canonical, geo-tags en
  Schema.org JSON-LD (LocalBusiness + FAQ) overgenomen van de oude site.
- **Hero-afbeelding** gecomprimeerd (427 → 349 KB) voor snellere laadtijd.

## Correcties t.o.v. het aangeleverde ontwerp
- Borg Trailer 1: €200 → **€190** (op de trailerkaart én in de FAQ).
- "B-rijbewijs voldoende" consequent voor beide trailers (geen "BE" meer).
- Footer: © 2026, KvK-vermelding verwijderd.
- Aankondigingsbalk: "1 trailer beschikbaar" → "2 trailers beschikbaar".

## Bewust NIET gedaan
- Geen Facebook Pixel (op jouw verzoek weggelaten).
- Geen KvK-nummer (op jouw verzoek weggelaten).
- De huurovereenkomst-flow blijft handmatig: klant vraagt aan via WhatsApp,
  jij stuurt daarna de link naar het huurformulier. De site linkt daar niet naar.

## Na livegang testen
- [ ] Formulier → opent WhatsApp met ingevuld bericht
- [ ] Google Calendar toont (laadt op de echte site, niet in een previewsandbox)
- [ ] GA4 Realtime: klik op WhatsApp/bel/reserveren en zie de events binnenkomen
- [ ] Clarity: eerste opnames verschijnen na enkele bezoeken
- [ ] Mobiel: sticky onderbalk (Bellen / WhatsApp / Reserveer) werkt
